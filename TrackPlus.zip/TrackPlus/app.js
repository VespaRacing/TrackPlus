const express = require('express');
const bodyParser = require('body-parser');
const fs =  require('fs'); //Modulo per leggere e modificare i dati
const PORT =3000;

const app = express();
app.use(bodyParser.json());



app.post('/loginUser', (req, res) => {
    const { type, username, password, age, city, email, phone_number } = req.body;

    // Validazione dei dati
    if (!type || !username || !password || !age || !city || !email || !phone_number) {
        return res.status(400).json({ message: 'Dati mancanti: controlla tutti i campi richiesti' });
    }

    if (type !== 'user') {
        return res.status(400).json({ message: 'Tipo non valido, deve essere "user"' });
    }

    // Legge il file utenti.json
    fs.readFile('utenti.json', 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ message: 'Errore nella lettura del file utenti.json' });
        }

        try {
            const utenti = JSON.parse(data);

            // Verifica se l'utente esiste già
            const userExists = utenti.find(u => u.user === username);
            if (userExists) {
                // Se l'utente esiste, restituisce i suoi dati
                return res.status(200).json({
                    type: "user",
                    username: userExists.user,
                    password: userExists.pwd,
                    age: userExists.age,
                    city: userExists.city,
                    email: userExists.email,
                    phone_number: userExists.phone_number
                });
            }

            // Aggiungi il nuovo profilo guidatore
            const nuovoGuidatore = { 
                type, 
                user: username, 
                pwd: password, 
                age, 
                city, 
                email, 
                phone_number 
            };
            utenti.push(nuovoGuidatore);

            // Salva il file aggiornato
            fs.writeFile('utenti.json', JSON.stringify(utenti, null, 2), (err) => {
                if (err) {
                    return res.status(500).json({ message: 'Errore nel salvataggio del file utenti.json' });
                }

                res.status(201).json({ message: 'Profilo guidatore aggiunto con successo', nuovoGuidatore });
            });
        } catch (err) {
            res.status(500).json({ message: 'Errore nel parsing del file utenti.json' });
        }
    });
});


app.post('/loginTrack', (req, res) => {
    const { type, username, password, city } = req.body;

    // Validazione dei dati
    if (!type || !username || !password || !city) {
        return res.status(400).json({ message: 'Dati mancanti: controlla tutti i campi richiesti' });
    }

    if (type !== 'track') {
        return res.status(400).json({ message: 'Tipo non valido, deve essere "track"' });
    }

    // Legge il file utenti.json
    fs.readFile('piste.json', 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ message: 'Errore nella lettura del file utenti.json' });
        }

        try {
            const utenti = JSON.parse(data);

            // Verifica se la pista esiste già
            const trackExists = utenti.find(u => u.user === username && u.type === 'track');
            if (trackExists) {
                // Se la pista esiste già, restituisce i suoi dati
                return res.status(200).json({
                    type: "track",
                    username: trackExists.user,
                    password: trackExists.pwd,
                    city: trackExists.city,
                    images: trackExists.images || [],
                    reviews: trackExists.reviews || ["", ""]
                });
            }

            // Aggiungi il nuovo profilo pista
            const nuovaPista = { 
                type, 
                user: username, 
                pwd: password, 
                city, 
                images: [], 
                reviews: ["", ""]
            };
            utenti.push(nuovaPista);

            // Salva il file aggiornato
            fs.writeFile('utenti.json', JSON.stringify(utenti, null, 2), (err) => {
                if (err) {
                    return res.status(500).json({ message: 'Errore nel salvataggio del file utenti.json' });
                }

                res.status(201).json({
                    type: "track",
                    username: nuovaPista.user,
                    password: nuovaPista.pwd,
                    city: nuovaPista.city,
                    images: nuovaPista.images,
                    reviews: nuovaPista.reviews
                });
            });
        } catch (err) {
            res.status(500).json({ message: 'Errore nel parsing del file utenti.json' });
        }
    });
});


app.delete('/deleteUser', (req, res) => {
    const { username, password } = req.body;

    // Validazione dei dati
    if (!username || !password) {
        return res.status(400).json({ message: 'Dati mancanti: username o password' });
    }

    // Legge il file utenti.json
    fs.readFile('utenti.json', 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ message: 'Errore nella lettura del file utenti.json' });
        }

        try {
            let utenti = JSON.parse(data);

            // Trova l'utente da eliminare (solo utenti, non piste)
            const userIndex = utenti.findIndex(u => u.user === username && u.pwd === password && u.type === 'user');

            if (userIndex === -1) {
                return res.status(404).json({ message: 'Utente non trovato o credenziali errate' });
            }

            // Rimuove l'utente dall'array
            utenti.splice(userIndex, 1);

            // Salva il file aggiornato
            fs.writeFile('utenti.json', JSON.stringify(utenti, null, 2), (err) => {
                if (err) {
                    return res.status(500).json({ message: 'Errore nel salvataggio del file utenti.json' });
                }

                // Risposta di successo con username e password null
                res.status(200).json({
                    username: null,
                    password: null
                });
            });
        } catch (err) {
            return res.status(500).json({ message: 'Errore nel parsing del file utenti.json' });
        }
    });
});


app.delete('/deleteTrack', (req, res) => {
    const { username, password } = req.body;

    // Validazione dei dati
    if (!username || !password) {
        return res.status(400).json({ message: 'Dati mancanti: username o password' });
    }

    // Legge il file utenti.json
    fs.readFile('utenti.json', 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ message: 'Errore nella lettura del file utenti.json' });
        }

        try {
            let utenti = JSON.parse(data);

            // Trova la pista da eliminare (solo piste, non utenti)
            const trackIndex = utenti.findIndex(u => u.user === username && u.pwd === password && u.type === 'track');

            if (trackIndex === -1) {
                return res.status(404).json({ message: 'Pista non trovata o credenziali errate' });
            }

            // Rimuove la pista dall'array
            utenti.splice(trackIndex, 1);

            // Salva il file aggiornato
            fs.writeFile('utenti.json', JSON.stringify(utenti, null, 2), (err) => {
                if (err) {
                    return res.status(500).json({ message: 'Errore nel salvataggio del file utenti.json' });
                }

                // Risposta di successo con username e password null
                res.status(200).json({
                    username: null,
                    password: null
                });
            });
        } catch (err) {
            return res.status(500).json({ message: 'Errore nel parsing del file utenti.json' });
        }
    });
});

app.post('/searchTrack', (req, res) => {
    const { trackName } = req.body;

    // Validazione dei dati
    if (!trackName) {
        return res.status(400).json({ message: 'Nome della pista mancante' });
    }

    // Legge il file utenti.json
    fs.readFile('utenti.json', 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ message: 'Errore nella lettura del file utenti.json' });
        }

        try {
            const utenti = JSON.parse(data);

            // Cerca la pista per nome (solo piste, non utenti)
            const track = utenti.find(u => u.user === trackName && u.type === 'track');

            if (!track) {
                return res.status(404).json({ message: 'Pista non trovata' });
            }

            // Restituisce i dettagli della pista
            res.status(200).json({
                username: track.user,
                password: track.pwd,
                city: track.city,
                images: track.images || [],
                reviews: track.reviews || []
            });
        } catch (err) {
            return res.status(500).json({ message: 'Errore nel parsing del file utenti.json' });
        }
    });
});

app.post('/bookTrack', (req, res) => {
    const { name, username, date, tickets_number } = req.body;

    // Validazione dei dati
    if (!name || !username || !date || !tickets_number) {
        return res.status(400).json({ message: 'Dati mancanti: nome della pista, username, data o numero di biglietti' });
    }

    // Legge il file utenti.json per verificare se la pista esiste
    fs.readFile('utenti.json', 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ message: 'Errore nella lettura del file utenti.json' });
        }

        try {
            const utenti = JSON.parse(data);

            // Cerca la pista per nome
            const track = utenti.find(u => u.user === name && u.type === 'track');

            if (!track) {
                return res.status(404).json({ message: 'Pista non trovata' });
            }

            // Se la pista è trovata, legge il file bookings.json
            fs.readFile('bookings.json', 'utf8', (err, bookingsData) => {
                let bookings = [];

                if (!err) {
                    try {
                        bookings = JSON.parse(bookingsData); // Parsea il file bookings.json se esiste
                    } catch (err) {
                        return res.status(500).json({ message: 'Errore nel parsing del file bookings.json' });
                    }
                }

                // Aggiunge la nuova prenotazione
                const newBooking = {
                    name: name,
                    username: username,
                    date: date,
                    tickets_number: tickets_number
                };

                bookings.push(newBooking);

                // Salva la prenotazione nel file bookings.json
                fs.writeFile('bookings.json', JSON.stringify(bookings, null, 2), (err) => {
                    if (err) {
                        return res.status(500).json({ message: 'Errore nel salvataggio della prenotazione' });
                    }

                    // Risposta di successo
                    res.status(200).json({
                        name: name,
                        status: "ok",
                        date: date,
                        tickets_number: tickets_number
                    });
                });
            });
        } catch (err) {
            return res.status(500).json({ message: 'Errore nel parsing del file utenti.json' });
        }
    });
});

app.post('/bookVehicle', (req, res) => {
    const { name, track, username, date, vehicles_number } = req.body;

    // Validazione dei dati
    if (!name || !track || !username || !date || !vehicles_number) {
        return res.status(400).json({ message: 'Dati mancanti: nome del veicolo, pista, username, data o numero di veicoli' });
    }

    // Legge il file utenti.json per verificare se la pista esiste
    fs.readFile('piste.json', 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ message: 'Errore nella lettura del file piste.json' });
        }

        try {
            const utenti = JSON.parse(data);

            // Cerca la pista per nome
            const trackFound = utenti.find(u => u.user === track && u.type === 'track');

            if (!trackFound) {
                return res.status(404).json({ message: 'Pista non trovata' });
            }

            // Se la pista è trovata, legge il file vehicles.json
            fs.readFile('vehicles.json', 'utf8', (err, vehiclesData) => {
                let vehicles = [];

                if (!err) {
                    try {
                        vehicles = JSON.parse(vehiclesData); // Parsea il file vehicles.json se esiste
                    } catch (err) {
                        return res.status(500).json({ message: 'Errore nel parsing del file vehicles.json' });
                    }
                }

                // Aggiungi la nuova prenotazione del veicolo
                const newVehicleBooking = {
                    name: name,
                    track: track,
                    username: username,
                    date: date,
                    vehicles_number: vehicles_number
                };

                vehicles.push(newVehicleBooking);

                // Salva la prenotazione nel file vehicles.json
                fs.writeFile('vehicles.json', JSON.stringify(vehicles, null, 2), (err) => {
                    if (err) {
                        return res.status(500).json({ message: 'Errore nel salvataggio della prenotazione del veicolo' });
                    }

                    // Risposta di successo
                    res.status(200).json(newVehicleBooking);
                });
            });
        } catch (err) {
            return res.status(500).json({ message: 'Errore nel parsing del file utenti.json' });
        }
    });
});


app.listen(PORT,()=>{
    console.log(`server in esecuzione sulla porta ${PORT}`);
});